import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const html = await readFile(resolve(root, 'index.html'), 'utf8');
const css = await readFile(resolve(root, 'styles.css'), 'utf8');
const panels = [...html.matchAll(/data-panel="([^"]+)"/g)].map(m => m[1]);
assert.equal(new Set(panels).size, panels.length, 'Duplicate panel');
for (const route of ['home', 'about', 'experience', 'paintings', 'water']) {
  assert(panels.includes(route), `Missing panel: ${route}`);
  assert(html.includes(`data-tab-link="${route}"`), `Missing navigation: ${route}`);
}
const refs = [
  ...[...html.matchAll(/(?:src|href|data)="([^"]+)"/g)].map(m => m[1]),
  ...[...css.matchAll(/url\(["']?([^\)"']+)/g)].map(m => m[1])
];
let checked = 0;
for (const ref of new Set(refs)) {
  if (/^(?:[a-z]+:|#|\/\/)/i.test(ref)) continue;
  const path = resolve(root, decodeURIComponent(ref.split(/[?#]/)[0]));
  assert((await stat(path)).isFile(), `Missing asset: ${ref}`);
  if (path.endsWith('.pdf')) {
    assert((await readFile(path)).subarray(0, 5).toString() === '%PDF-', `Invalid PDF: ${ref}`);
  }
  checked++;
}
const manifest = JSON.parse(await readFile(resolve(root, '.openai/hosting.json'), 'utf8'));
assert(manifest.project_id, 'Missing existing Sites project ID');
assert(html.includes('assets/gallery/calligraphy-full.jpg'), 'Full calligraphy must be preserved');
console.log(`Passed: ${panels.length} panels, ${checked} local references, linked PDF headers, Sites manifest.`);
